package com.spriteapp.utillibrary;

/**
 * Created by kuangxiaoguo on 2017/12/13.
 */

public class ScreenUtil {

    public static void dp2px() {
    }

    public static void haha() {
    }
}
